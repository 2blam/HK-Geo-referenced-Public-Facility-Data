LIBRARY_LCSD_20131213.csv

Row# 187 has some problem 

The English Name of such entry with extra \t

It introduces error in processing this csv file.

To prevent error, I manually remove the extra \t and the duplicated English Name.

Note: Please don't use excel, use notepad++ / sublime to fix the csv file.